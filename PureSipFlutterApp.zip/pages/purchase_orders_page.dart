import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:printing/printing.dart';
import '../widgets/company_selector.dart';
import '../services/company_service.dart';
import '../utils/pdf_exporter.dart';

class PurchaseOrdersPage extends StatefulWidget {
  const PurchaseOrdersPage({super.key});

  @override
  State<PurchaseOrdersPage> createState() => _PurchaseOrdersPageState();
}

class _PurchaseOrdersPageState extends State<PurchaseOrdersPage> {
  String? selectedCompany;
  String vendorFilter = '';
  DateTime? startDate;
  DateTime? endDate;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Purchase Orders'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: CompanySelector(
              onCompanySelected: (companyId) {
                setState(() => selectedCompany = companyId);
              },
            ),
          ),
        ],
      ),
      body: selectedCompany == null
          ? const Center(child: Text('Please select a company'))
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          decoration: const InputDecoration(labelText: 'Filter by vendor'),
                          onChanged: (value) {
                            setState(() => vendorFilter = value);
                          },
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.date_range),
                        onPressed: () async {
                          final picked = await showDateRangePicker(
                            context: context,
                            firstDate: DateTime(2020),
                            lastDate: DateTime.now().add(const Duration(days: 365)),
                          );
                          if (picked != null) {
                            setState(() {
                              startDate = picked.start;
                              endDate = picked.end;
                            });
                          }
                        },
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('companies/$selectedCompany/purchase_orders')
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return const Center(child: CircularProgressIndicator());
                      }

                      final allOrders = snapshot.data!.docs;
                      final orders = allOrders.where((doc) {
                        final data = doc.data() as Map<String, dynamic>;
                        final vendor = data['vendorId']?.toString().toLowerCase() ?? '';
                        final createdAt = (data['createdAt'] as Timestamp?)?.toDate();
                        final matchesVendor = vendor.contains(vendorFilter.toLowerCase());
                        final matchesDate = (startDate == null || endDate == null || (createdAt != null && createdAt.isAfter(startDate!) && createdAt.isBefore(endDate!.add(const Duration(days: 1)))));
                        return matchesVendor && matchesDate;
                      }).toList();

                      if (orders.isEmpty) {
                        return const Center(child: Text('No purchase orders match your filters.'));
                      }

                      return ListView.builder(
                        itemCount: orders.length,
                        itemBuilder: (context, index) {
                          final order = orders[index];
                          final data = order.data() as Map<String, dynamic>;
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            child: ListTile(
                              title: Text('PO #${order.id}'),
                              subtitle: Text('Vendor: ${data['vendorId']}\nTotal: \$${data['totalAmount']}'),
                              trailing: IconButton(
                                icon: const Icon(Icons.picture_as_pdf),
                                onPressed: () async {
                                  final pdf = await generatePurchaseOrderPdf(order.id, data);
                                  await Printing.layoutPdf(onLayout: (format) async => pdf.save());
                                },
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}