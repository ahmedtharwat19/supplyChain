
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show kIsWeb;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    throw UnsupportedError(
      'DefaultFirebaseOptions are not supported for this platform.',
    );
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBLh1kz54d-85FzETal_pUp1hgizty_rFk',
    appId: '1:80836764748:web:6c76e96f665112ce49c0e9',
    messagingSenderId: '80836764748',
    projectId: 'puresip-purchasing',
    authDomain: 'puresip-purchasing.firebaseapp.com',
    storageBucket: 'puresip-purchasing.appspot.com',
    measurementId: '',
  );
}
